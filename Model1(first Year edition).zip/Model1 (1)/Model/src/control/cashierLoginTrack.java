package control;

public class cashierLoginTrack {
public static void cashierTrack() {
	
}
}
