package control;
import javafx.stage.Stage;
public class managerMenu2GeneralButton {
public static void generalButton(Stage primaryStage) {
	view.Manager.managerGeneralButton(primaryStage);
}
}
