package control;
import javafx.stage.Stage;
public class managerMenu2GeneralButtonStatisticalReport {
public static void generalStats(Stage primaryStage,String start,String end) {
	view.Manager.generalList(primaryStage, start, end);
}
}
