package control;
import javafx.stage.Stage;

public class button1Login {
public static void cashierLoginTransition(Stage primaryStage) {
                 view.mainLogin.cashierLogin(primaryStage);
}
}
 