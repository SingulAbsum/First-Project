package control;

import javafx.stage.Stage;

public class administratorMenu4StatisticalReport {
	public static void stats(Stage primaryStage,String start,String end) {
		view.Administrator.statisticsList(primaryStage, start, end);
	}
}
