package view;

public class administratorLogin {

}
