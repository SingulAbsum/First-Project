package control.admin;
import javafx.stage.Stage;
public class Administrator {
public static void menu1(Stage primaryStage) {
	view.Administrator.menu1(primaryStage);
}
public static void menu2(Stage primaryStage) {
	view.Administrator.menu2(primaryStage);
}
public static void menu3(Stage primaryStage) {
	view.Administrator.menu3(primaryStage);
}
public static void menu4(Stage primaryStage) {
	view.Administrator.menu4(primaryStage);
}

}
