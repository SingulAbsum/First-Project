package control.auth;

public class cashierLoginTrack {
public static void cashierTrack() {
	
}
}
