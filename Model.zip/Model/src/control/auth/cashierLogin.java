package control.auth;
import javafx.stage.Stage;
public class cashierLogin {
	public static void login(Stage primaryStage,String username,String password) {
		System.out.println("Attempting login for username: " + username);
		System.out.println("Password entered: " + password);
		
		// For testing purposes, allow login with any non-empty credentials
		// TODO: Replace with proper database check once SQLite driver is available
		if(username != null && !username.trim().isEmpty() && password != null && !password.trim().isEmpty()) {
			System.out.println("Credentials valid (test mode), proceeding to terminal...");
			// Try to insert activity, but don't block login if it fails
			try {
				model.updateInsert.insertNewCashierActivity(username);
				System.out.println("Activity logged successfully");
			} catch (Exception e) {
				System.out.println("Activity logging failed, but login continues: " + e.getMessage());
			}
	        if(model.Database.checkCredentialsCashier(username, password)==true){
			view.mainLogin.cashierLoginTerminal(primaryStage);
			}
			else{
				view.mainLogin.loginAlert();	
			}
		}
		else {
			System.out.println("Invalid credentials - empty username or password");
			view.mainLogin.loginAlert();
		}
	}
	public static void loginTerminal(Stage primaryStage) {
			view.mainLogin.cashierLoginTerminal(primaryStage);
	}

}
