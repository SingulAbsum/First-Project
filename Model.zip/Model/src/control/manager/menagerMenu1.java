package control.manager;
import javafx.stage.Stage;
public class menagerMenu1 {
public static void menagerMenu1(Stage primaryStage) {
	view.Manager.menu1(primaryStage);
}
}
