package control.manager;
import javafx.stage.Stage;
public class managerMenu2CashierButton {
public static void cashier(Stage primaryStage) {
	view.Manager.managerCashierButton(primaryStage);
}
}
