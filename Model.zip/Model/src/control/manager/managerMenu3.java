package control.manager;
import javafx.stage.Stage;
public class managerMenu3 {
	public static void managerMenu3(Stage primaryStage) {
		view.Manager.menu3(primaryStage);
	}

}
