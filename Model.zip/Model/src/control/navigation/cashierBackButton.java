package control.navigation;
import javafx.stage.Stage;
public class cashierBackButton {
	public static void back(Stage primaryStage) {
		view.mainLogin.home(primaryStage);
	}

}
