package main;

import javafx.application.Application;

public class Main {

	public static void main(String[] args) {
	Application.launch(view.mainLogin.class, args);
}

}
