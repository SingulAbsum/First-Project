package view;

import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Modern Manager Interface - High Contrast & Excellent Readability
 * Features: Contemporary styling, vibrant colors, enhanced UX with clear visibility
 */
public class Manager {
	
	// Modern high-contrast color palette with excellent readability
	private static final String PRIMARY_BLUE = "#0066FF";
	private static final String PRIMARY_GREEN = "#00CC66";
	private static final String PRIMARY_ORANGE = "#FF6600";
	private static final String PRIMARY_PURPLE = "#9933FF";
	private static final String DARK_BG = "#0A0A0A";
	private static final String CARD_BG = "#1A1A1A";
	private static final String LIGHT_BG = "#2A2A2A";
	private static final String TEXT_WHITE = "#FFFFFF";
	private static final String TEXT_BRIGHT = "#F0F0F0";
	private static final String TEXT_SECONDARY = "#CCCCCC";
	private static final String SUCCESS_COLOR = "#00AA44";
	private static final String WARNING_COLOR = "#FF8800";
	private static final String ERROR_COLOR = "#FF4444";
	/**
	 * Modern Add New Product Interface - High Contrast Design
	 */
	public static void menu3(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📦 ADD NEW PRODUCT");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Product Management System");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Form card with modern styling
		VBox formCard = new VBox(25);
		formCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 30; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		formCard.setAlignment(Pos.CENTER);
		
		// Product Name Section
		VBox productNameSection = createInputSection("🌍 Product Name", "Enter product name");
		TextField newProductName = createModernTextField("Enter product name");
		productNameSection.getChildren().add(newProductName);
		
		// Product Quantity Section
		VBox productQuantitySection = createInputSection("📊 Product Quantity", "Enter quantity");
		TextField productQuantity = createModernTextField("Enter quantity");
		productQuantitySection.getChildren().add(productQuantity);
		
		// Product Price Section
		VBox productPriceSection = createInputSection("💰 Product Price", "Enter price");
		TextField productPrice = createModernTextField("Enter price");
		productPriceSection.getChildren().add(productPrice);
		
		// Product Sector Section
		VBox productSectorSection = createInputSection("🏷️ Product Sector", "Enter sector");
		TextField productSector = createModernTextField("Enter sector");
		productSectorSection.getChildren().add(productSector);
		
		// Supplier ID Section
		VBox supplierIdSection = createInputSection("🔍 Supplier ID", "Enter supplier ID");
		TextField supplierId = createModernTextField("Enter supplier ID");
		supplierIdSection.getChildren().add(supplierId);
		
		// Form layout
		VBox formLayout = new VBox(20);
		formLayout.getChildren().addAll(productNameSection, productQuantitySection, productPriceSection, productSectorSection, supplierIdSection);
		
		// Navigation and Action buttons
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button addNewProduct = createModernButton("🚀 ADD PRODUCT", SUCCESS_COLOR, 200, 60);
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		buttonSection.getChildren().addAll(travel, addNewProduct);
		
		formCard.getChildren().addAll(formLayout, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, formCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		addNewProduct.setOnAction(_ -> {
			control.manager.managerMenu3AddNewProduct.addNewProduct(newProductName.getText(), productQuantity.getText(), productPrice.getText(), productSector.getText(), supplierId.getText());
		});
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
	}
	
	/**
	 * Helper method to create modern input sections with excellent readability
	 */
	private static VBox createInputSection(String labelText, String placeholder) {
		VBox section = new VBox(8);
		Label label = new Label(labelText);
		label.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		label.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		section.getChildren().add(label);
		return section;
	}
	
	/**
	 * Helper method to create modern text fields with high contrast
	 */
	private static TextField createModernTextField(String placeholder) {
		TextField textField = new TextField();
		textField.setPromptText(placeholder);
		textField.setPrefSize(300, 50);
		textField.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_GREEN, TEXT_SECONDARY
		));
		return textField;
	}
	
	/**
	 * Helper method to create modern buttons with high contrast
	 */
	private static Button createModernButton(String text, String color, int width, int height) {
		Button button = new Button(text);
		button.setPrefSize(width, height);
		button.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold;",
			color, darkenColor(color), TEXT_WHITE, color
		));
		
		// Enhanced hover effects
		button.setOnMouseEntered(_ -> button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 4; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.6), 20, 0, 0, 8); -fx-font-weight: bold; -fx-scale-x: 1.05; -fx-scale-y: 1.05;",
			lightenColor(color), color, TEXT_WHITE, lightenColor(color)
		)));
		
		button.setOnMouseExited(_ -> button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold; -fx-scale-x: 1.0; -fx-scale-y: 1.0;",
			color, darkenColor(color), TEXT_WHITE, color
		)));
		
		return button;
	}
	
	/**
	 * Helper method to create modern menu buttons
	 */
	private static MenuButton createModernMenuButton(String text, String color, int width, int height) {
		MenuButton menuButton = new MenuButton(text);
		menuButton.setPrefSize(width, height);
		menuButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		menuButton.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold;",
			color, darkenColor(color), TEXT_WHITE, color
		));
		return menuButton;
	}
	
	/**
	 * Helper method to darken colors for gradients
	 */
	private static String darkenColor(String color) {
		return color + "CC"; // Add transparency for darker effect
	}
	
	/**
	 * Helper method to lighten colors for hover effects
	 */
	private static String lightenColor(String color) {
		return color + "FF"; // Full opacity for lighter effect
	}

	/**
	 * Modern Add Product Category Interface - High Contrast Design
	 */
	public static void menu1(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📂 ADD PRODUCT CATEGORY");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Category Management System");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Form card with modern styling
		VBox formCard = new VBox(25);
		formCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 30; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		formCard.setAlignment(Pos.CENTER);
		
		// Product Information Section
		VBox productNameSection = createInputSection("🌍 Product Name", "Enter product name");
		TextField newProductName = createModernTextField("Enter product name");
		productNameSection.getChildren().add(newProductName);
		
		VBox productQuantitySection = createInputSection("📊 Product Quantity", "Enter quantity");
		TextField productQuantity = createModernTextField("Enter quantity");
		productQuantitySection.getChildren().add(productQuantity);
		
		VBox productPriceSection = createInputSection("💰 Product Price", "Enter price");
		TextField productPrice = createModernTextField("Enter price");
		productPriceSection.getChildren().add(productPrice);
		
		VBox productSectorSection = createInputSection("🏷️ Product Sector", "Enter sector");
		TextField productSector = createModernTextField("Enter sector");
		productSectorSection.getChildren().add(productSector);
		
		// Supplier Information Section
		VBox supplierIdSection = createInputSection("🔍 Supplier ID", "Enter supplier ID");
		TextField supplierId = createModernTextField("Enter supplier ID");
		supplierIdSection.getChildren().add(supplierId);
		
		VBox supplierNameSection = createInputSection("👤 Supplier Name", "Enter supplier name");
		TextField supplierName = createModernTextField("Enter supplier name");
		supplierNameSection.getChildren().add(supplierName);
		
		VBox supplierCategorySection = createInputSection("📁 Supplier Category", "Enter supplier category");
		TextField supplierCategory = createModernTextField("Enter supplier category");
		supplierCategorySection.getChildren().add(supplierCategory);
		
		// Form layout
		VBox formLayout = new VBox(20);
		formLayout.getChildren().addAll(productNameSection, productQuantitySection, productPriceSection, productSectorSection, supplierIdSection, supplierNameSection, supplierCategorySection);
		
		// Navigation and Action buttons
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button addNewProductCategory = createModernButton("🚀 ADD CATEGORY", SUCCESS_COLOR, 200, 60);
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		buttonSection.getChildren().addAll(travel, addNewProductCategory);
		
		formCard.getChildren().addAll(formLayout, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, formCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		addNewProductCategory.setOnAction(_ -> {
			control.manager.managerMenu1AddNewProductCategory.addNewProductCategory(
				newProductName.getText(), productQuantity.getText(), productPrice.getText(), 
				productSector.getText(), supplierId.getText(), supplierName.getText(), supplierCategory.getText()
			);
		});
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
	}

	/**
	 * Modern Notifications Interface - High Contrast Design
	 */
	public static void menu4(Stage primaryStage, int sectorNr) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("🔔 NOTIFICATIONS & REFILL");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Inventory Management - Sector " + sectorNr);
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Notifications card with modern styling
		VBox notificationsCard = new VBox(25);
		notificationsCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 30; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		
		ObservableList<String> base = model.Get.getNotifications(sectorNr);
		ListView<String> list = new ListView<>();
		list.setItems(base);
		list.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 2; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-family: 'Segoe UI'; -fx-font-size: 14px; -fx-font-weight: bold;",
			DARK_BG, TEXT_WHITE, PRIMARY_ORANGE
		));
		list.setPrefHeight(400);
		list.setPrefWidth(800);
		
		list.setCellFactory(_ -> new ListCell<String>() {
			@Override
			protected void updateItem(String name, boolean state) {
				super.updateItem(name, state);
				if (state || name == null) {
					setGraphic(null);
				} else {
					// Create modern refill interface
					VBox itemContainer = new VBox(15);
					itemContainer.setStyle(String.format(
						"-fx-background-color: %s; -fx-background-radius: 10; -fx-padding: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
						LIGHT_BG
					));
					
					Label productLabel = new Label("📦 " + name);
					productLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
					productLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
					
					HBox refillSection = new HBox(20);
					refillSection.setAlignment(Pos.CENTER_LEFT);
					
					Label quantityLabel = new Label("Quantity:");
					quantityLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
					quantityLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
					
					TextField quantity = new TextField();
					quantity.setPromptText("Enter quantity");
					quantity.setPrefSize(120, 40);
					quantity.setStyle(String.format(
						"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 2; -fx-border-radius: 8; -fx-background-radius: 8; -fx-font-size: 14px; -fx-font-weight: bold; -fx-prompt-text-fill: %s;",
						DARK_BG, TEXT_WHITE, PRIMARY_ORANGE, TEXT_SECONDARY
					));
					
					Button refillButton = createModernButton("🔄 REFILL", SUCCESS_COLOR, 120, 40);
					
					refillSection.getChildren().addAll(quantityLabel, quantity, refillButton);
					itemContainer.getChildren().addAll(productLabel, refillSection);
					
					setGraphic(itemContainer);
					setPrefWidth(800);
					setPrefHeight(100);
					
					refillButton.setOnAction(_ -> {
						control.manager.managerMenu4RefillButton.refill(name, quantity.getText(), String.valueOf(sectorNr));
						list.setItems(model.Get.getNotifications(sectorNr));
					});
				}
			}
		});
		
		notificationsCard.getChildren().add(list);
		
		// Navigation section
		HBox navigationSection = new HBox(30);
		navigationSection.setAlignment(Pos.CENTER);
		
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		navigationSection.getChildren().add(travel);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, notificationsCard, navigationSection);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
	}

	/**
	 * Modern Statistics Selection Interface - High Contrast Design
	 */
	public static void menu2(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📊 STATISTICS CENTER");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Analytics & Reporting Dashboard");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Statistics card with modern styling
		VBox statisticsCard = new VBox(30);
		statisticsCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		statisticsCard.setAlignment(Pos.CENTER);
		
		// Statistics buttons section
		HBox statisticsSection = new HBox(40);
		statisticsSection.setAlignment(Pos.CENTER);
		
		Button cashierStats = createModernButton("👤 CASHIER STATISTICS", PRIMARY_GREEN, 250, 80);
		Button generalStats = createModernButton("📈 GENERAL STATISTICS", PRIMARY_ORANGE, 250, 80);
		
		statisticsSection.getChildren().addAll(cashierStats, generalStats);
		
		// Navigation section
		HBox navigationSection = new HBox(30);
		navigationSection.setAlignment(Pos.CENTER);
		
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		navigationSection.getChildren().add(travel);
		
		statisticsCard.getChildren().addAll(statisticsSection, navigationSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, statisticsCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		cashierStats.setOnAction(_ -> control.manager.managerMenu2CashierButton.cashier(primaryStage));
		generalStats.setOnAction(_ -> control.manager.managerMenu2GeneralButton.generalButton(primaryStage));
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
	}

	/**
	 * Modern Cashier Report Generator - High Contrast Design
	 */
	public static void managerCashierButton(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("👤 CASHIER REPORT GENERATOR");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Generate Detailed Cashier Performance Reports");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Form card with modern styling
		VBox formCard = new VBox(30);
		formCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		formCard.setAlignment(Pos.CENTER);
		
		// Cashier Name Section
		VBox cashierNameSection = createInputSection("👤 Cashier Name", "Enter cashier name");
		TextField cashierName = createModernTextField("Enter cashier name");
		cashierNameSection.getChildren().add(cashierName);
		
		// Date Range Section
		VBox dateRangeSection = new VBox(20);
		Label dateRangeLabel = new Label("📅 Date Range");
		dateRangeLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
		dateRangeLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		VBox startDateSection = createInputSection("📅 Start Date", "Format: MDDYYYY (no dots)");
		TextField startDate = createModernTextField("Enter start date");
		startDateSection.getChildren().add(startDate);
		
		VBox endDateSection = createInputSection("📅 End Date", "Format: MDDYYYY (no dots)");
		TextField endDate = createModernTextField("Enter end date");
		endDateSection.getChildren().add(endDate);
		
		dateRangeSection.getChildren().addAll(dateRangeLabel, startDateSection, endDateSection);
		
		// Action buttons section
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button generateButton = createModernButton("📊 GENERATE REPORT", SUCCESS_COLOR, 200, 60);
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		MenuItem travel4 = new MenuItem("📊 Report Selection");
		travel.getItems().addAll(travel1, travel2, travel3, travel4);
		
		buttonSection.getChildren().addAll(travel, generateButton);
		
		formCard.getChildren().addAll(cashierNameSection, dateRangeSection, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, formCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		generateButton.setOnAction(_ -> {
			control.manager.managerMenu2CashierButtonGenerateButton.generate(primaryStage, cashierName.getText(), startDate.getText(), endDate.getText());
		});
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
		travel4.setOnAction(_ -> control.manager.managerMenu2.managerMenu2(primaryStage));
	}

	/**
	 * Modern Cashier Statistics Display - High Contrast Design
	 */
	public static void cashierList(Stage primaryStage, String name, String start, String end) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📊 CASHIER PERFORMANCE REPORT");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Cashier: " + name + " | Period: " + start + " - " + end);
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Statistics card with modern styling
		VBox statisticsCard = new VBox(30);
		statisticsCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		statisticsCard.setAlignment(Pos.CENTER);
		
		// Statistics display section
		HBox statisticsSection = new HBox(40);
		statisticsSection.setAlignment(Pos.CENTER);
		
		// Bills Generated
		VBox billsSection = new VBox(15);
		Label billsLabel = new Label("📄 Bills Generated");
		billsLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
		billsLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button totalBillsButton = new Button(String.valueOf(model.Return.returnTotalBills(name, start, end)));
		totalBillsButton.setPrefSize(200, 100);
		totalBillsButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 24));
		totalBillsButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5);",
			PRIMARY_BLUE, TEXT_WHITE, PRIMARY_BLUE
		));
		
		billsSection.getChildren().addAll(billsLabel, totalBillsButton);
		
		// Items Sold
		VBox itemsSection = new VBox(15);
		Label itemsLabel = new Label("🛒 Items Sold");
		itemsLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
		itemsLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button totalItemsButton = new Button(String.valueOf(model.Return.returnTotalItems(name, start, end)));
		totalItemsButton.setPrefSize(200, 100);
		totalItemsButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 24));
		totalItemsButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5);",
			SUCCESS_COLOR, TEXT_WHITE, SUCCESS_COLOR
		));
		
		itemsSection.getChildren().addAll(itemsLabel, totalItemsButton);
		
		// Total Revenue
		VBox revenueSection = new VBox(15);
		Label revenueLabel = new Label("💰 Total Revenue");
		revenueLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
		revenueLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button totalRevenueButton = new Button(String.valueOf(model.Return.returnTotalRevenue(name, start, end)));
		totalRevenueButton.setPrefSize(200, 100);
		totalRevenueButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 24));
		totalRevenueButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5);",
			WARNING_COLOR, TEXT_WHITE, WARNING_COLOR
		));
		
		revenueSection.getChildren().addAll(revenueLabel, totalRevenueButton);
		
		statisticsSection.getChildren().addAll(billsSection, itemsSection, revenueSection);
		
		// Navigation section
		HBox navigationSection = new HBox(30);
		navigationSection.setAlignment(Pos.CENTER);
		
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_PURPLE, 250, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		MenuItem travel4 = new MenuItem("📊 Report Selection");
		MenuItem travel5 = new MenuItem("📈 Generate Report");
		travel.getItems().addAll(travel1, travel2, travel3, travel4, travel5);
		
		navigationSection.getChildren().add(travel);
		
		statisticsCard.getChildren().addAll(statisticsSection, navigationSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, statisticsCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
		travel4.setOnAction(_ -> control.manager.managerMenu2.managerMenu2(primaryStage));
		travel5.setOnAction(_ -> control.manager.managerMenu2CashierButton.cashier(primaryStage));
	}

	/**
	 * Modern General Report Generator - High Contrast Design
	 */
	public static void managerGeneralButton(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📈 GENERAL REPORT GENERATOR");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Generate Comprehensive Business Analytics");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Form card with modern styling
		VBox formCard = new VBox(30);
		formCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		formCard.setAlignment(Pos.CENTER);
		
		// Date Range Section
		VBox dateRangeSection = new VBox(20);
		Label dateRangeLabel = new Label("📅 Date Range Selection");
		dateRangeLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
		dateRangeLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		VBox startDateSection = createInputSection("📅 Start Date", "Format: MDDYYYY (no dots)");
		TextField startDate = createModernTextField("Enter start date");
		startDateSection.getChildren().add(startDate);
		
		VBox endDateSection = createInputSection("📅 End Date", "Format: MDDYYYY (no dots)");
		TextField endDate = createModernTextField("Enter end date");
		endDateSection.getChildren().add(endDate);
		
		dateRangeSection.getChildren().addAll(dateRangeLabel, startDateSection, endDateSection);
		
		// Action buttons section
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button generateButton = createModernButton("📊 GENERATE REPORT", SUCCESS_COLOR, 200, 60);
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 200, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		MenuItem travel4 = new MenuItem("📊 Report Selection");
		travel.getItems().addAll(travel1, travel2, travel3, travel4);
		
		buttonSection.getChildren().addAll(travel, generateButton);
		
		formCard.getChildren().addAll(dateRangeSection, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, formCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		generateButton.setOnAction(_ -> {
			control.manager.managerMenu2GeneralButtonStatisticalReport.generalStats(primaryStage, startDate.getText(), endDate.getText());
		});
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
		travel4.setOnAction(_ -> control.manager.managerMenu2.managerMenu2(primaryStage));
	}

	/**
	 * Modern General Statistics Display - High Contrast Design
	 */
	public static void generalList(Stage primaryStage, String start, String end) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Label title = new Label("📈 GENERAL BUSINESS ANALYTICS");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 32));
		title.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Label subtitle = new Label("Period: " + start + " - " + end);
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setStyle(String.format("-fx-text-fill: %s;", TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Statistics card with modern styling
		VBox statisticsCard = new VBox(30);
		statisticsCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		statisticsCard.setAlignment(Pos.CENTER);
		
		// Statistics display section
		HBox statisticsSection = new HBox(30);
		statisticsSection.setAlignment(Pos.CENTER);
		
		// Items Sold
		VBox itemsSoldSection = new VBox(15);
		Label itemsSoldLabel = new Label("🛒 Items Sold");
		itemsSoldLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		itemsSoldLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button totalItemsSoldButton = new Button(String.valueOf(model.Return.returnItemsSold()));
		totalItemsSoldButton.setPrefSize(180, 80);
		totalItemsSoldButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
		totalItemsSoldButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 12; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 4);",
			SUCCESS_COLOR, TEXT_WHITE, SUCCESS_COLOR
		));
		
		itemsSoldSection.getChildren().addAll(itemsSoldLabel, totalItemsSoldButton);
		
		// Items Purchased
		VBox itemsPurchasedSection = new VBox(15);
		Label itemsPurchasedLabel = new Label("📦 Items Purchased");
		itemsPurchasedLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		itemsPurchasedLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button totalItemsPurchasedButton = new Button(String.valueOf(model.Return.returnItemsPurchased()));
		totalItemsPurchasedButton.setPrefSize(180, 80);
		totalItemsPurchasedButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
		totalItemsPurchasedButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 12; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 4);",
			PRIMARY_BLUE, TEXT_WHITE, PRIMARY_BLUE
		));
		
		itemsPurchasedSection.getChildren().addAll(itemsPurchasedLabel, totalItemsPurchasedButton);
		
		// Revenue from Sales
		VBox salesRevenueSection = new VBox(15);
		Label salesRevenueLabel = new Label("💰 Sales Revenue");
		salesRevenueLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		salesRevenueLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button salesRevenueButton = new Button(String.valueOf(model.Return.returnItemsSoldRevenue()));
		salesRevenueButton.setPrefSize(180, 80);
		salesRevenueButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
		salesRevenueButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 12; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 4);",
			WARNING_COLOR, TEXT_WHITE, WARNING_COLOR
		));
		
		salesRevenueSection.getChildren().addAll(salesRevenueLabel, salesRevenueButton);
		
		// Revenue from Purchases
		VBox purchaseRevenueSection = new VBox(15);
		Label purchaseRevenueLabel = new Label("💸 Purchase Revenue");
		purchaseRevenueLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		purchaseRevenueLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button purchaseRevenueButton = new Button(String.valueOf(model.Return.returnItemsPurchasedRevenue()));
		purchaseRevenueButton.setPrefSize(180, 80);
		purchaseRevenueButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
		purchaseRevenueButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 12; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 4);",
			PRIMARY_PURPLE, TEXT_WHITE, PRIMARY_PURPLE
		));
		
		purchaseRevenueSection.getChildren().addAll(purchaseRevenueLabel, purchaseRevenueButton);
		
		// Balance
		VBox balanceSection = new VBox(15);
		Label balanceLabel = new Label("⚖️ Balance");
		balanceLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		balanceLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		Button balanceButton = new Button(String.valueOf(model.Return.returnItemsSoldRevenue() - model.Return.returnItemsPurchasedRevenue()));
		balanceButton.setPrefSize(180, 80);
		balanceButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
		balanceButton.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 12; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 4);",
			ERROR_COLOR, TEXT_WHITE, ERROR_COLOR
		));
		
		balanceSection.getChildren().addAll(balanceLabel, balanceButton);
		
		statisticsSection.getChildren().addAll(itemsSoldSection, itemsPurchasedSection, salesRevenueSection, purchaseRevenueSection, balanceSection);
		
		// Navigation section
		HBox navigationSection = new HBox(30);
		navigationSection.setAlignment(Pos.CENTER);
		
		MenuButton travel = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 250, 60);
		MenuItem travel1 = new MenuItem("🏠 Main Login");
		MenuItem travel2 = new MenuItem("👔 Manager Login");
		MenuItem travel3 = new MenuItem("💻 Manager Terminal");
		MenuItem travel4 = new MenuItem("📊 Report Selection");
		MenuItem travel5 = new MenuItem("📈 Generate Report");
		travel.getItems().addAll(travel1, travel2, travel3, travel4, travel5);
		
		navigationSection.getChildren().add(travel);
		
		statisticsCard.getChildren().addAll(statisticsSection, navigationSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, statisticsCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		travel1.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		travel2.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
		travel3.setOnAction(_ -> control.auth.managerLogin.loginTerminal(primaryStage));
		travel4.setOnAction(_ -> control.manager.managerMenu2.managerMenu2(primaryStage));
		travel5.setOnAction(_ -> control.manager.managerMenu2GeneralButton.generalButton(primaryStage));
	}
}