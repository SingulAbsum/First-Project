package view;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
public class Administrator {
	// Modern color palette
	private static final String PRIMARY_COLOR = "#2C3E50";
	private static final String SECONDARY_COLOR = "#3498DB";
	private static final String SUCCESS_COLOR = "#27AE60";
	private static final String WARNING_COLOR = "#F39C12";
	private static final String DANGER_COLOR = "#E74C3C";
	private static final String DARK_BG = "#1A1A1A";
	private static final String CARD_BG = "#2C2C2C";
	private static final String TEXT_PRIMARY = "#FFFFFF";
	private static final String TEXT_SECONDARY = "#BDC3C7";
	
	public static void menu1(Stage primaryStage) {
	    // Modern navigation button with glassmorphism effect
	    MenuButton travel = createModernMenuButton("Go to", 220, 60);
	    travel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
	    MenuItem travel1 = new MenuItem("Login");
	    MenuItem travel2 = new MenuItem("Administrator Login");
	    MenuItem travel3 = new MenuItem("Administrator Terminal");
	    travel.getItems().addAll(travel1, travel2, travel3);

	    // Modern action buttons with consistent styling
	    Button addNewProductCategory = createModernButton("Add Cashier", SUCCESS_COLOR, 220, 50);

	    Button addNewProductCategor = createModernButton("Add Manager", SECONDARY_COLOR, 220, 50);

	    Button addNewProductCatego = createModernButton("Add Administrator", WARNING_COLOR, 220, 50);

	    // Modern form fields with consistent styling
	    TextField newProductName = createModernTextField("Id");
	    TextField productQuantity = createModernTextField("Name");
	    TextField productPrice = createModernTextField("Birthdate");
	    TextField productSector = createModernTextField("Phone Number");
	    TextField supplierId = createModernTextField("Email");
	    TextField supplierName = createModernTextField("Salary");
	    TextField supplierCategory = createModernTextField("Access Level");
	    TextField username = createModernTextField("Username");
	    TextField password = createModernTextField("Password");
	    TextField sector = createModernTextField("Sector");

	    // Modern form labels with consistent styling
	    Label npN = createModernLabel("Id:");
	    Label npQ = createModernLabel("Name:");
	    Label npP = createModernLabel("Birthdate:");
	    Label npS = createModernLabel("Phone Number:");
	    Label sI = createModernLabel("Email:");
	    Label sN = createModernLabel("Salary:");
	    Label sC = createModernLabel("Access Level:");
	    Label uN = createModernLabel("Username:");
	    Label pW = createModernLabel("Password:");
	    Label sec = createModernLabel("Sector:");
	    // Modern form layout with card-based design
	    VBox formContainer = new VBox(15);
	    formContainer.getChildren().addAll(
	            createFormGroup(npN, newProductName),
	            createFormGroup(npQ, productQuantity),
	            createFormGroup(npP, productPrice),
	            createFormGroup(npS, productSector),
	            createFormGroup(sI, supplierId),
	            createFormGroup(sN, supplierName),
	            createFormGroup(sC, supplierCategory),
	            createFormGroup(uN, username),
	            createFormGroup(pW, password),
	            createFormGroup(sec, sector)
	    );
	    
	    // Action buttons container
	    VBox buttonContainer = new VBox(10);
	    buttonContainer.getChildren().addAll(addNewProductCategory, addNewProductCategor, addNewProductCatego);
	    buttonContainer.setAlignment(Pos.CENTER);
	    
	    VBox mainContainer = new VBox(20);
	    mainContainer.getChildren().addAll(formContainer, buttonContainer, travel);
	    mainContainer.setAlignment(Pos.CENTER);
	    
	    ScrollPane scroll = createModernScrollPane(mainContainer);
	    Scene newProduct = new Scene(scroll, 1200, 800);
	    primaryStage.setScene(newProduct);
	    addNewProductCategory.setOnAction(p -> {
	        control.admin.administratorMenu1AddCashierButton.addCashier(
	                newProductName.getText(),
	                productQuantity.getText(),
	                productPrice.getText(),
	                productSector.getText(),
	                supplierId.getText(),
	                supplierName.getText(),
	                supplierCategory.getText(),
	                username.getText(),
	                password.getText(),
	                sector.getText()
	        );
	    });
            addNewProductCategor.setOnAction(p -> {
	        control.admin.administratorMenu1AddManagerButton.addManager(
	                newProductName.getText(),
	                productQuantity.getText(),
	                productPrice.getText(),
	                productSector.getText(),
	                supplierId.getText(),
	                supplierName.getText(),
	                supplierCategory.getText(),
	                username.getText(),
	                password.getText(),
	                sector.getText()
	        );
	    });
	    addNewProductCatego.setOnAction(p -> {
	        control.admin.administratorMenu1AddAdministratorButton.addAdministrator(
	                newProductName.getText(),
	                productQuantity.getText(),
	                productPrice.getText(),
	                productSector.getText(),
	                supplierId.getText(),
	                supplierName.getText(),
	                supplierCategory.getText(),
	                username.getText(),
	                password.getText(),
	                sector.getText()
	        );
	    });
	    travel1.setOnAction(z -> control.navigation.cashierBackButton.back(primaryStage));
	    travel2.setOnAction(zh -> control.navigation.button3Login.administratorLoginTransition(primaryStage));
	    travel3.setOnAction(zh -> control.auth.administratorLogin.loginTerminal(primaryStage));
	}

	// Modern styling helper methods
	private static MenuButton createModernMenuButton(String text, double width, double height) {
	    MenuButton button = new MenuButton(text);
	    button.setPrefSize(width, height);
	    button.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
	    button.setStyle(
	        "-fx-background-color: linear-gradient(to bottom, " + PRIMARY_COLOR + ", #34495E);" +
	        "-fx-text-fill: " + TEXT_PRIMARY + ";" +
	        "-fx-border-color: " + SECONDARY_COLOR + ";" +
	        "-fx-border-radius: 12;" +
	        "-fx-background-radius: 12;" +
	        "-fx-border-width: 2;" +
	        "-fx-padding: 12 24 12 24;" +
	        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 8, 0, 0, 2);"
	    );
	    return button;
	}
	
	private static Button createModernButton(String text, String color, double width, double height) {
	    Button button = new Button(text);
	    button.setPrefSize(width, height);
	    button.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 16));
	    button.setStyle(
	        "-fx-background-color: linear-gradient(to bottom, " + color + ", " + darkenColor(color) + ");" +
	        "-fx-text-fill: " + TEXT_PRIMARY + ";" +
	        "-fx-border-color: " + darkenColor(color) + ";" +
	        "-fx-border-radius: 10;" +
	        "-fx-background-radius: 10;" +
	        "-fx-border-width: 2;" +
	        "-fx-padding: 10 20 10 20;" +
	        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 6, 0, 0, 2);"
	    );
	    
	    // Hover effects
	    button.setOnMouseEntered(e -> button.setStyle(button.getStyle() + "-fx-scale-x: 1.05; -fx-scale-y: 1.05;"));
	    button.setOnMouseExited(e -> button.setStyle(button.getStyle().replace("-fx-scale-x: 1.05; -fx-scale-y: 1.05;", "")));
	    
	    return button;
	}
	
	private static TextField createModernTextField(String promptText) {
	    TextField textField = new TextField();
	    textField.setPromptText(promptText);
	    textField.setPrefSize(350, 45);
	    textField.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
	    textField.setStyle(
	        "-fx-background-color: " + CARD_BG + ";" +
	        "-fx-text-fill: " + TEXT_PRIMARY + ";" +
	        "-fx-border-color: " + SECONDARY_COLOR + ";" +
	        "-fx-border-radius: 8;" +
	        "-fx-background-radius: 8;" +
	        "-fx-border-width: 2;" +
	        "-fx-padding: 8 12 8 12;" +
	        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 4, 0, 0, 1);"
	    );
	    
	    // Focus effects
	    textField.focusedProperty().addListener((obs, oldVal, newVal) -> {
	        if (newVal) {
	            textField.setStyle(textField.getStyle().replace("-fx-border-color: " + SECONDARY_COLOR, "-fx-border-color: #3498DB"));
	        } else {
	            textField.setStyle(textField.getStyle().replace("-fx-border-color: #3498DB", "-fx-border-color: " + SECONDARY_COLOR));
	        }
	    });
	    
	    return textField;
	}

	private static Label createModernLabel(String text) {
	    Label label = new Label(text);
	    label.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 16));
	    label.setStyle("-fx-text-fill: " + TEXT_SECONDARY + ";");
	    return label;
	}
	
	private static VBox createFormGroup(Label label, TextField textField) {
	    VBox group = new VBox(5);
	    group.getChildren().addAll(label, textField);
	    group.setAlignment(Pos.CENTER_LEFT);
	    return group;
	}
	
	private static ScrollPane createModernScrollPane(VBox content) {
	    ScrollPane scrollPane = new ScrollPane(content);
	    scrollPane.setFitToWidth(true);
	    scrollPane.setFitToHeight(true);
	    scrollPane.setStyle(
	        "-fx-background-color: " + DARK_BG + ";" +
	        "-fx-border-color: transparent;" +
	        "-fx-padding: 20;"
	    );
	    content.setStyle(
	        "-fx-background-color: " + DARK_BG + ";" +
	        "-fx-padding: 30;"
	    );
	    return scrollPane;
	}
	
	private static ChoiceBox<String> createModernChoiceBox(String... items) {
	    return createModernChoiceBox(items, 200, 50);
	}
	
	private static ChoiceBox<String> createModernChoiceBox(String[] items, double width, double height) {
	    ChoiceBox<String> choiceBox = new ChoiceBox<>();
	    choiceBox.getItems().addAll(items);
	    choiceBox.setPrefSize(width, height);
	    choiceBox.setStyle(
	        "-fx-background-color: " + CARD_BG + ";" +
	        "-fx-text-fill: " + TEXT_PRIMARY + ";" +
	        "-fx-border-color: " + SECONDARY_COLOR + ";" +
	        "-fx-border-radius: 8;" +
	        "-fx-background-radius: 8;" +
	        "-fx-border-width: 2;" +
	        "-fx-padding: 8 12 8 12;" +
	        "-fx-font-size: 14;" +
	        "-fx-font-family: 'Segoe UI';"
	    );
	    return choiceBox;
	}
	
	private static ComboBox<String> createModernComboBox(double width, double height) {
	    ComboBox<String> comboBox = new ComboBox<>();
	    comboBox.setPrefSize(width, height);
	    comboBox.setStyle(
	        "-fx-background-color: " + CARD_BG + ";" +
	        "-fx-text-fill: " + TEXT_PRIMARY + ";" +
	        "-fx-border-color: " + SECONDARY_COLOR + ";" +
	        "-fx-border-radius: 8;" +
	        "-fx-background-radius: 8;" +
	        "-fx-border-width: 2;" +
	        "-fx-padding: 8 12 8 12;" +
	        "-fx-font-size: 14;" +
	        "-fx-font-family: 'Segoe UI';"
	    );
	    return comboBox;
	}
	
	private static VBox createStatCard(String title, String value, String color, String description) {
	    VBox card = new VBox(15);
	    card.setStyle(
	        "-fx-background-color: " + CARD_BG + ";" +
	        "-fx-background-radius: 15;" +
	        "-fx-padding: 25;" +
	        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 3);"
	    );
	    
	    Label titleLabel = new Label(title);
	    titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
	    titleLabel.setStyle("-fx-text-fill: " + color + ";");
	    
	    Label valueLabel = new Label(value);
	    valueLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
	    valueLabel.setStyle("-fx-text-fill: " + TEXT_PRIMARY + ";");
	    
	    Label descLabel = new Label(description);
	    descLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
	    descLabel.setStyle("-fx-text-fill: " + TEXT_SECONDARY + ";");
	    
	    card.getChildren().addAll(titleLabel, valueLabel, descLabel);
	    card.setAlignment(javafx.geometry.Pos.CENTER);
	    card.setPrefWidth(300);
	    
	    return card;
	}
	
	private static String darkenColor(String color) {
	    // Simple color darkening for gradients
	    switch(color) {
	        case SUCCESS_COLOR: return "#1E8449";
	        case SECONDARY_COLOR: return "#2980B9";
	        case WARNING_COLOR: return "#D68910";
	        case DANGER_COLOR: return "#C0392B";
	        default: return "#2C3E50";
	    }
	}

	public static void menu2(Stage primaryStage) {
		// Modern edit interface with improved styling
		MenuButton travel = createModernMenuButton("Go to", 200, 60);
		MenuItem travel1 = new MenuItem("Login");
		MenuItem travel2 = new MenuItem("Administrator Login");
		MenuItem travel3 = new MenuItem("Administrator Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		// Modern form controls
		ChoiceBox<String> role = createModernChoiceBox(new String[]{"Cashier", "Manager", "Administrator"}, 250, 50);
		ChoiceBox<String> field = createModernChoiceBox(new String[]{"id", "name", "birthdate", "phone number", "email", "salary", "access level", "username", "password", "sector"}, 250, 50);
		
		TextField newField = createModernTextField("new value");
		newField.setPrefSize(350, 45);
		
		Label nF = createModernLabel("New Value:");
		VBox nV = createFormGroup(nF, newField);
		
		ComboBox<String> name = createModernComboBox(350, 45);
		name.setOnAction(r -> {
			name.getItems().addAll(model.Return.returnName(role.getValue()));
		});
		name.setEditable(true);
		
		Button edit = createModernButton("Edit", SUCCESS_COLOR, 200, 50);
		
		// Modern layout with card-based design
		VBox formCard = new VBox(20);
		formCard.setStyle(
			"-fx-background-color: " + CARD_BG + ";" +
			"-fx-background-radius: 15;" +
			"-fx-padding: 30;" +
			"-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 3);"
		);
		
		HBox first = new HBox(30);
		first.getChildren().addAll(role, field);
		first.setAlignment(javafx.geometry.Pos.CENTER);
		
		HBox second = new HBox(30);
		second.getChildren().addAll(nV, name);
		second.setAlignment(javafx.geometry.Pos.CENTER);
		
		formCard.getChildren().addAll(first, second, edit);
		formCard.setAlignment(javafx.geometry.Pos.CENTER);
		
		VBox mainContainer = new VBox(30);
		mainContainer.getChildren().addAll(formCard, travel);
		mainContainer.setAlignment(javafx.geometry.Pos.CENTER);
		mainContainer.setStyle("-fx-background-color: " + DARK_BG + "; -fx-padding: 40;");
		
		Scene editable = new Scene(mainContainer, 1200, 800);
		primaryStage.setScene(editable);
		edit.setOnAction(rr -> {
			control.admin.administratorMenu2EditButton.edit(role.getValue(), field.getValue(), newField.getText(), name.getValue());
		});
		travel1.setOnAction(z -> {
			control.navigation.cashierBackButton.back(primaryStage);
		});
		travel2.setOnAction(zh -> {
			control.navigation.button3Login.administratorLoginTransition(primaryStage);
		});
		travel3.setOnAction(zh -> {
			control.auth.administratorLogin.loginTerminal(primaryStage);
		});
	}

	public static void menu3(Stage primaryStage) {
		// Modern delete interface with warning styling
		MenuButton travel = createModernMenuButton("Go to", 200, 60);
		MenuItem travel1 = new MenuItem("Login");
		MenuItem travel2 = new MenuItem("Administrator Login");
		MenuItem travel3 = new MenuItem("Administrator Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		// Modern form controls for deletion
		ChoiceBox<String> role = createModernChoiceBox(new String[]{"Cashier", "Manager", "Administrator"}, 300, 50);
		ComboBox<String> name = createModernComboBox(300, 50);
		name.setOnAction(r -> {
			name.getItems().addAll(model.Return.returnName(role.getValue()));
		});
		name.setEditable(true);
		
		// Warning-styled delete button
		Button edit = createModernButton("Delete", DANGER_COLOR, 250, 60);
		edit.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		
		// Modern card layout with warning theme
		VBox deleteCard = new VBox(25);
		deleteCard.setStyle(
			"-fx-background-color: " + CARD_BG + ";" +
			"-fx-background-radius: 15;" +
			"-fx-padding: 40;" +
			"-fx-effect: dropshadow(gaussian, rgba(231,76,60,0.3), 15, 0, 0, 5);"
		);
		
		Label warningLabel = new Label("⚠️ Delete User Account");
		warningLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
		warningLabel.setStyle("-fx-text-fill: " + DANGER_COLOR + ";");
		
		Label infoLabel = new Label("Select the user role and name to delete");
		infoLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
		infoLabel.setStyle("-fx-text-fill: " + TEXT_SECONDARY + ";");
		
		deleteCard.getChildren().addAll(warningLabel, infoLabel, role, name, edit);
		deleteCard.setAlignment(javafx.geometry.Pos.CENTER);
		
		VBox mainContainer = new VBox(30);
		mainContainer.getChildren().addAll(deleteCard, travel);
		mainContainer.setAlignment(javafx.geometry.Pos.CENTER);
		mainContainer.setStyle("-fx-background-color: " + DARK_BG + "; -fx-padding: 40;");
		
		Scene editable = new Scene(mainContainer, 1200, 800);
		primaryStage.setScene(editable);
		edit.setOnAction(rr -> {
			control.admin.administratorMenu2DeleteButton.edit(role.getValue(), name.getValue());
		});
		travel1.setOnAction(z -> {
			control.navigation.cashierBackButton.back(primaryStage);
		});
		travel2.setOnAction(zh -> {
			control.navigation.button3Login.administratorLoginTransition(primaryStage);
		});
		travel3.setOnAction(zh -> {
			control.auth.administratorLogin.loginTerminal(primaryStage);
		});
	}

	public static void menu4(Stage primaryStage) {
		// Modern report generation interface
		MenuButton travel = createModernMenuButton("Go to", 200, 60);
		MenuItem travel1 = new MenuItem("Login");
		MenuItem travel2 = new MenuItem("Administrator Login");
		MenuItem travel3 = new MenuItem("Administrator Terminal");
		travel.getItems().addAll(travel1, travel2, travel3);
		
		// Modern date input fields
		TextField start = createModernTextField("Starting Date (Format: MDDYYYY)");
		start.setPrefSize(350, 45);
		TextField end = createModernTextField("Ending Date (Format: MDDYYYY)");
		end.setPrefSize(350, 45);
		
		Label s = createModernLabel("Enter Starting Date:");
		Label e = createModernLabel("Enter Ending Date:");
		
		VBox startS = createFormGroup(s, start);
		VBox endE = createFormGroup(e, end);
		
		Button generate = createModernButton("Generate Report", SECONDARY_COLOR, 280, 60);
		generate.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		
		// Modern report card layout
		VBox reportCard = new VBox(25);
		reportCard.setStyle(
			"-fx-background-color: " + CARD_BG + ";" +
			"-fx-background-radius: 15;" +
			"-fx-padding: 40;" +
			"-fx-effect: dropshadow(gaussian, rgba(52,152,219,0.3), 15, 0, 0, 5);"
		);
		
		Label titleLabel = new Label("📊 Generate Statistical Report");
		titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
		titleLabel.setStyle("-fx-text-fill: " + SECONDARY_COLOR + ";");
		
		reportCard.getChildren().addAll(titleLabel, startS, endE, generate);
		reportCard.setAlignment(javafx.geometry.Pos.CENTER);
		
		VBox mainContainer = new VBox(30);
		mainContainer.getChildren().addAll(reportCard, travel);
		mainContainer.setAlignment(javafx.geometry.Pos.CENTER);
		mainContainer.setStyle("-fx-background-color: " + DARK_BG + "; -fx-padding: 40;");
		
		Scene stats = new Scene(mainContainer, 1200, 800);
		primaryStage.setScene(stats);
		generate.setOnAction(t -> {
			control.admin.administratorMenu4StatisticalReport.stats(primaryStage, start.getText(), end.getText());
		});
		travel1.setOnAction(z -> {
			control.navigation.cashierBackButton.back(primaryStage);
		});
		travel2.setOnAction(zh -> {
			control.navigation.button3Login.administratorLoginTransition(primaryStage);
		});
		travel3.setOnAction(zh -> {
			control.auth.administratorLogin.loginTerminal(primaryStage);
		});
	}

	public static void statisticsList(Stage primaryStage, String start, String end) {
		// Modern statistics dashboard
		MenuButton travel = createModernMenuButton("Go to", 200, 60);
		MenuItem travel1 = new MenuItem("Login");
		MenuItem travel2 = new MenuItem("Administrator Login");
		MenuItem travel3 = new MenuItem("Administrator Terminal");
		MenuItem travel4 = new MenuItem("Generate Report");
		travel.getItems().addAll(travel1, travel2, travel3, travel4);
		
		// Modern statistics cards
		String revenue = String.valueOf(model.Return.returnItemsSoldRevenueTimed(start, end));
		String expense = String.valueOf(model.Return.returnFinalTotalExpense(start, end));
		String balance = String.valueOf(model.Return.returnItemsSoldRevenue() - model.Return.returnFinalTotalExpense(start, end));
		
		VBox revenueCard = createStatCard("💰 Total Revenue", revenue, SUCCESS_COLOR, "Revenue from Items Sold:");
		VBox expenseCard = createStatCard("💸 Total Expense", expense, DANGER_COLOR, "Expense from Items Purchased:");
		VBox balanceCard = createStatCard("⚖️ Balance", balance, WARNING_COLOR, "Overall Balance:");
		
		// Modern dashboard layout
		HBox statsContainer = new HBox(20);
		statsContainer.getChildren().addAll(revenueCard, expenseCard, balanceCard);
		statsContainer.setAlignment(javafx.geometry.Pos.CENTER);
		
		VBox mainContainer = new VBox(30);
		mainContainer.getChildren().addAll(statsContainer, travel);
		mainContainer.setAlignment(javafx.geometry.Pos.CENTER);
		mainContainer.setStyle("-fx-background-color: " + DARK_BG + "; -fx-padding: 40;");
		
		Scene show = new Scene(mainContainer, 1400, 800);
		primaryStage.setScene(show);
		travel1.setOnAction(z -> {
			control.navigation.cashierBackButton.back(primaryStage);
		});
		travel2.setOnAction(zh -> {
			control.navigation.button3Login.administratorLoginTransition(primaryStage);
		});
		travel3.setOnAction(zh -> {
			control.auth.administratorLogin.loginTerminal(primaryStage);
		});
		travel4.setOnAction(zh -> {
			control.admin.Administrator.menu4(primaryStage);
		});
	}

}
