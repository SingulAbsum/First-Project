package view;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DialogPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.*;
import javafx.geometry.Pos;

/**
 * Modern Cashier Interface - Contemporary UI with enhanced user experience
 * Features: Sleek design, improved typography, modern color schemes
 */
public class Cashier {
	
	// Modern color palette
	private static final String PRIMARY_COLOR = "#667eea";
	private static final String SECONDARY_COLOR = "#764ba2";
	private static final String SUCCESS_COLOR = "#11998e";
	private static final String ERROR_COLOR = "#ff416c";
	private static final String DARK_BG = "#1a1a2e";
	private static final String CARD_BG = "#16213e";
	private static final String TEXT_LIGHT = "#e8e8e8";
	private static final String TEXT_SECONDARY = "#a0a0a0";
	
	/**
	 * Main Cashier Terminal - Modern POS Interface
	 */
	public static void menu1(Stage primaryStage) {
		// Create main container with modern gradient background
		VBox mainContainer = new VBox(30);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header Section
		VBox headerSection = new VBox(10);
		headerSection.setAlignment(Pos.CENTER);
		
		Label titleLabel = new Label("🛒 CASHIER TERMINAL");
		titleLabel.setStyle(String.format(
			"-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_LIGHT
		));
		
		Label subtitleLabel = new Label("Modern Point of Sale System");
		subtitleLabel.setStyle(String.format(
			"-fx-font-size: 16px; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_SECONDARY
		));
		
		headerSection.getChildren().addAll(titleLabel, subtitleLabel);
		
		// Input Form Section with modern card design
		VBox formCard = new VBox(25);
		formCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 30; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 20, 0, 0, 5);",
			CARD_BG
		));
		
		// Product Name Input
		VBox productNameSection = createInputSection("📦 Product Name");
		ComboBox<String> productName = createModernComboBox("Enter product name...");
		productNameSection.getChildren().add(productName);
		
		// Product Sector Input
		VBox productSectorSection = createInputSection("🏷️ Product Sector");
		TextField productSector = createModernTextField("Enter sector...");
		productSectorSection.getChildren().add(productSector);
		
		// Quantity Input
		VBox quantitySection = createInputSection("🔢 Quantity");
		TextField quantity = createModernTextField("Enter quantity...");
		quantitySection.getChildren().add(quantity);
		
		// Add Button
		Button addButton = createModernButton("➕ ADD TO CART", SUCCESS_COLOR, "16px");
		addButton.setPrefWidth(150);
		
		// Setup product name autocomplete
		ObservableList<String> names = model.Return.returnAllProductNames();
		productName.setItems(names);
		productName.getEditor().textProperty().addListener((_, _, newValue) -> {
			if (newValue == null || newValue.isEmpty()) return;
			FXCollections.sort(names, (a, b) -> {
				if (a.startsWith(newValue) && !b.startsWith(newValue)) return -1;
				else if (!a.startsWith(newValue) && b.startsWith(newValue)) return 1;
				else return a.compareTo(b);
			});
		});
		
		// Form layout
		HBox formRow = new HBox(30);
		formRow.getChildren().addAll(productNameSection, productSectorSection, quantitySection, addButton);
		formRow.setAlignment(Pos.CENTER_LEFT);
		
		formCard.getChildren().add(formRow);
		
		// Cart Display Section
		VBox cartSection = new VBox(15);
		cartSection.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 15; -fx-padding: 20;",
			DARK_BG
		));
		
		Label cartTitle = new Label("🛍️ Shopping Cart");
		cartTitle.setStyle(String.format(
			"-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_LIGHT
		));
		
		ObservableList<String> cartItems = FXCollections.observableArrayList();
		ListView<String> cartList = createModernListView();
		cartList.setItems(cartItems);
		cartList.setPrefHeight(200);
		
		// Total and Finish Section
		HBox totalSection = new HBox(20);
		totalSection.setAlignment(Pos.CENTER);
		
		Label totalLabel = new Label("💰 Total: " + model.Return.getTotal());
		totalLabel.setStyle(String.format(
			"-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			SUCCESS_COLOR
		));
		
		Button finishButton = createModernButton("✅ COMPLETE PURCHASE", SUCCESS_COLOR, "18px");
		finishButton.setPrefWidth(200);
		
		totalSection.getChildren().addAll(totalLabel, finishButton);
		
		cartSection.getChildren().addAll(cartTitle, cartList, totalSection);
		
		// Navigation Menu
		MenuButton navMenu = createModernMenuButton("🧭 NAVIGATION");
		MenuItem loginItem = new MenuItem("🔐 Main Login");
		MenuItem cashierLoginItem = new MenuItem("👤 Cashier Login");
		MenuItem terminalItem = new MenuItem("💻 Cashier Terminal");
		navMenu.getItems().addAll(loginItem, cashierLoginItem, terminalItem);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, formCard, cartSection, navMenu);
		
		// Create scene with modern dimensions
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Data storage
		HashMap<String, Integer> register = new HashMap<>();
		ArrayList<Integer> sec = new ArrayList<>();
		
		// Event handlers
		addButton.setOnAction(_ -> {
			control.cashier.menu1AddButton.add(productName.getValue(), quantity.getText(), productSector.getText(), totalLabel, register, sec, cartItems);
			productName.getEditor().clear();
			quantity.clear();
			productSector.clear();
		});
		
		finishButton.setOnAction(_ -> {
			control.cashier.menu1FinishButton.finish(register, sec, cartList, totalLabel.getText());
		});
		
		loginItem.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		cashierLoginItem.setOnAction(_ -> control.navigation.button1Login.cashierLoginTransition(primaryStage));
		terminalItem.setOnAction(_ -> control.auth.cashierLogin.loginTerminal(primaryStage));
	}
	
	/**
	 * Helper method to create modern input sections
	 */
	private static VBox createInputSection(String labelText) {
		VBox section = new VBox(8);
		Label label = new Label(labelText);
		label.setStyle(String.format(
			"-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_LIGHT
		));
		section.getChildren().add(label);
		return section;
	}
	
	/**
	 * Helper method to create modern combo box
	 */
	private static ComboBox<String> createModernComboBox(String promptText) {
		ComboBox<String> comboBox = new ComboBox<>();
		comboBox.setPromptText(promptText);
		comboBox.setEditable(true);
		comboBox.setPrefWidth(250);
		comboBox.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 14px; -fx-prompt-text-fill: %s; -fx-font-family: 'Segoe UI';",
			DARK_BG, TEXT_LIGHT, PRIMARY_COLOR, TEXT_SECONDARY
		));
		return comboBox;
	}
	
	/**
	 * Helper method to create modern text field
	 */
	private static TextField createModernTextField(String promptText) {
		TextField textField = new TextField();
		textField.setPromptText(promptText);
		textField.setPrefWidth(200);
		textField.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 14px; -fx-prompt-text-fill: %s; -fx-font-family: 'Segoe UI';",
			DARK_BG, TEXT_LIGHT, PRIMARY_COLOR, TEXT_SECONDARY
		));
		return textField;
	}
	
	/**
	 * Helper method to create modern button
	 */
	private static Button createModernButton(String text, String color, String fontSize) {
		Button button = new Button(text);
		button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: white; -fx-font-size: %s; -fx-font-weight: bold; -fx-border-radius: 12; -fx-background-radius: 12; -fx-padding: 12 24; -fx-font-family: 'Segoe UI'; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			color, darkenColor(color), fontSize
		));
		
		// Hover effect
		button.setOnMouseEntered(_ -> button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: white; -fx-font-size: %s; -fx-font-weight: bold; -fx-border-radius: 12; -fx-background-radius: 12; -fx-padding: 12 24; -fx-font-family: 'Segoe UI'; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 12, 0, 0, 3);",
			lightenColor(color), color, fontSize
		)));
		
		button.setOnMouseExited(_ -> button.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: white; -fx-font-size: %s; -fx-font-weight: bold; -fx-border-radius: 12; -fx-background-radius: 12; -fx-padding: 12 24; -fx-font-family: 'Segoe UI'; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			color, darkenColor(color), fontSize
		)));
		
		return button;
	}
	
	/**
	 * Helper method to create modern list view
	 */
	private static ListView<String> createModernListView() {
		ListView<String> listView = new ListView<>();
		listView.setStyle(String.format(
			"-fx-background-color: %s; -fx-border-color: %s; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-family: 'Segoe UI'; -fx-font-size: 14px;",
			DARK_BG, PRIMARY_COLOR
		));
		return listView;
	}
	
	/**
	 * Helper method to create modern menu button
	 */
	private static MenuButton createModernMenuButton(String text) {
		MenuButton menuButton = new MenuButton(text);
		menuButton.setPrefSize(250, 60);
		menuButton.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-border-radius: 15; -fx-background-radius: 15; -fx-font-family: 'Segoe UI';",
			SECONDARY_COLOR, PRIMARY_COLOR
		));
		return menuButton;
	}
	
	/**
	 * Helper method to darken color for gradients
	 */
	private static String darkenColor(String color) {
		return color + "dd"; // Add transparency for darker effect
	}
	
	/**
	 * Helper method to lighten color for hover effects
	 */
	private static String lightenColor(String color) {
		return color + "ff"; // Full opacity for lighter effect
	}

	/**
	 * Modern error alert for empty fields
	 */
	public static void emptyFields() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("⚠️ Validation Error");
		alert.setHeaderText("Empty Fields Detected");
		alert.setContentText("Please ensure all required fields are filled before proceeding.\n\n• Product Name\n• Product Sector\n• Quantity");
		styleModernAlert(alert, ERROR_COLOR);
		alert.showAndWait();
	}

	/**
	 * Modern error alert for product add failures
	 */
	public static void productAddError() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("❌ Product Error");
		alert.setHeaderText("Product Add Failure");
		alert.setContentText("Invalid product name or quantity detected.\n\nPlease verify your input and try again.");
		styleModernAlert(alert, ERROR_COLOR);
		alert.showAndWait();
	}

	/**
	 * Modern error alert for database update failures
	 */
	public static void productQuantityUpdateError() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("⚠️ Update Failure");
		alert.setHeaderText("Database Connection Error");
		alert.setContentText("Unable to update product quantity in database.\n\nPlease check database connectivity and try again.");
		styleModernAlert(alert, ERROR_COLOR);
		alert.showAndWait();
	}

	/**
	 * Modern success alert for completed operations
	 */
	public static void done() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("✅ Success");
		alert.setHeaderText("Transaction Completed");
		alert.setContentText("Your bill has been successfully recorded and saved to the database.\n\nThank you for your purchase!");
		styleModernAlert(alert, SUCCESS_COLOR);
		alert.showAndWait();
	}
	
	/**
	 * Helper method to style modern alerts
	 */
	private static void styleModernAlert(Alert alert, String accentColor) {
		DialogPane dialogPane = alert.getDialogPane();
		dialogPane.setStyle(String.format(
			"-fx-background-color: %s; -fx-border-color: %s; -fx-border-width: 2; -fx-border-radius: 15; -fx-background-radius: 15; -fx-font-family: 'Segoe UI'; -fx-font-size: 14px; -fx-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 15, 0, 0, 5);",
			CARD_BG, accentColor, TEXT_LIGHT
		));
	}


	/**
	 * Modern Bill History View - Enhanced file management interface
	 */
	public static void menu2(Stage primaryStage) {
		// Create main container with modern gradient background
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 40;",
			DARK_BG, CARD_BG
		));
		
		// Header Section
		VBox headerSection = new VBox(15);
		headerSection.setAlignment(Pos.CENTER);
		
		Label titleLabel = new Label("📋 BILL HISTORY");
		titleLabel.setStyle(String.format(
			"-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_LIGHT
		));
		
		Label subtitleLabel = new Label("Transaction Records & File Management");
		subtitleLabel.setStyle(String.format(
			"-fx-font-size: 16px; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_SECONDARY
		));
		
		headerSection.getChildren().addAll(titleLabel, subtitleLabel);
		
		// Navigation Menu
		MenuButton navMenu = createModernMenuButton("🧭 NAVIGATION");
		MenuItem loginItem = new MenuItem("🔐 Main Login");
		MenuItem cashierLoginItem = new MenuItem("👤 Cashier Login");
		MenuItem terminalItem = new MenuItem("💻 Cashier Terminal");
		navMenu.getItems().addAll(loginItem, cashierLoginItem, terminalItem);
		
		// Bill List Section
		VBox billListSection = new VBox(20);
		billListSection.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 30; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 20, 0, 0, 5);",
			CARD_BG
		));
		
		Label billListTitle = new Label("📄 Available Bills");
		billListTitle.setStyle(String.format(
			"-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			TEXT_LIGHT
		));
		
		ListView<Hyperlink> billListView = new ListView<>(control.cashier.menu2.menu2());
		billListView.setStyle(String.format(
			"-fx-background-color: %s; -fx-border-color: %s; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-family: 'Segoe UI'; -fx-font-size: 14px;",
			DARK_BG, PRIMARY_COLOR
		));
		billListView.setPrefHeight(400);
		
		// Total Bills Display
		HBox totalSection = new HBox(20);
		totalSection.setAlignment(Pos.CENTER);
		
		Label totalBillsLabel = new Label("📊 Total Bills: " + model.Get.getTotalBills());
		totalBillsLabel.setStyle(String.format(
			"-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: %s; -fx-font-family: 'Segoe UI';",
			SUCCESS_COLOR
		));
		
		totalSection.getChildren().add(totalBillsLabel);
		
		billListSection.getChildren().addAll(billListTitle, billListView, totalSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, navMenu, billListSection);
		
		// Create scene with modern dimensions
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		loginItem.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		cashierLoginItem.setOnAction(_ -> control.navigation.button1Login.cashierLoginTransition(primaryStage));
		terminalItem.setOnAction(_ -> control.auth.cashierLogin.loginTerminal(primaryStage));
	}

	/**
	 * Modern error alert for file not found
	 */
	public static void hyperlinkError(String fileName) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("📁 File Error");
		alert.setHeaderText("File Not Found");
		alert.setContentText(String.format("The requested file '%s' could not be found.\n\nPlease verify the file exists and try again.", fileName));
		styleModernAlert(alert, ERROR_COLOR);
		alert.showAndWait();
	}
	
	/**
	 * Modern information alert for no bills available
	 */
	public static void noBillsAlert() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("ℹ️ No Bills Found");
		alert.setHeaderText("No Bills Available");
		alert.setContentText("No bill files are currently available in the database.\n\nThis could mean:\n• No transactions have been completed yet\n• Bills are being processed\n• Database is being updated\n\nPlease try again later.");
		styleModernAlert(alert, PRIMARY_COLOR);
		alert.showAndWait();
	}


}



