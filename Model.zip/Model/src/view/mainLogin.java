package view;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.effect.Glow;
import javafx.scene.layout.HBox;
import javafx.scene.control.DialogPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.control.ButtonType;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;   

/**
 * Modern Main Login Interface - High Contrast & Bold Design
 * Features: Contemporary styling, vibrant colors, enhanced UX
 */
public class mainLogin extends Application {
	
	// Modern high-contrast color palette
	private static final String PRIMARY_BLUE = "#0066FF";
	private static final String PRIMARY_GREEN = "#00CC66";
	private static final String PRIMARY_RED = "#FF3366";
	private static final String DARK_BG = "#0A0A0A";
	private static final String CARD_BG = "#1A1A1A";
	private static final String TEXT_WHITE = "#FFFFFF";
	private static final String TEXT_BRIGHT = "#F0F0F0";
	private static final String ACCENT_PURPLE = "#9933FF";
	static Scene home;
	/**
	 * Modern Main Login Interface - High Contrast & Bold Design
	 */
	@Override
	public void start(Stage primaryStage) {
	    primaryStage.setTitle("🚀 MODERN POS SYSTEM");
	    primaryStage.setFullScreen(true);
	    
	    // Create main container with modern dark gradient
	    VBox mainContainer = new VBox(80);
	    mainContainer.setStyle(String.format(
	        "-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
	        DARK_BG, CARD_BG
	    ));
	    
	    // Modern header section
	    VBox headerSection = new VBox(20);
	    headerSection.setAlignment(Pos.CENTER);
	    
	    Text mainTitle = new Text("⚡ POS MANAGEMENT SYSTEM");
	    mainTitle.setFont(Font.font("Arial Black", FontWeight.BOLD, 48));
	    mainTitle.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
	    mainTitle.setEffect(new Glow(0.8));
	    
	    Text subtitle = new Text("Choose Your Access Level");
	    subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
	    subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
	    
	    headerSection.getChildren().addAll(mainTitle, subtitle);
	    
	    // Modern button container with card design
	    VBox buttonCard = new VBox(30);
	    buttonCard.setStyle(String.format(
	        "-fx-background-color: %s; -fx-background-radius: 25; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 30, 0, 0, 10);",
	        CARD_BG
	    ));
	    
	    // Create modern buttons with high contrast
	    Button cashierButton = createModernButton("💳 CASHIER", PRIMARY_BLUE, 200, 100);
	    Button managerButton = createModernButton("👔 MANAGER", PRIMARY_GREEN, 200, 100);
	    Button adminButton = createModernButton("⚙️ ADMINISTRATOR", PRIMARY_RED, 200, 100);
	    
	    HBox buttonLayout = new HBox(40);
	    buttonLayout.getChildren().addAll(adminButton, managerButton, cashierButton);
	    buttonLayout.setAlignment(Pos.CENTER);
	    
	    buttonCard.getChildren().add(buttonLayout);
	    
	    // Assemble main layout
	    mainContainer.getChildren().addAll(headerSection, buttonCard);
	    mainContainer.setAlignment(Pos.CENTER);
	    
	    home = new Scene(mainContainer, 1200, 900);
	    primaryStage.setScene(home);
	    
	    // Event handlers with modern styling
	    cashierButton.setOnAction(_ -> control.navigation.button1Login.cashierLoginTransition(primaryStage));
	    managerButton.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
	    adminButton.setOnAction(_ -> control.navigation.button3Login.administratorLoginTransition(primaryStage));

	    primaryStage.show();
	}

	/**
	 * Helper method to create modern high-contrast buttons
	 */
	private static Button createModernButton(String text, String color, int width, int height) {
	    Button button = new Button(text);
	    button.setPrefSize(width, height);
	    button.setFont(Font.font("Arial Black", FontWeight.BOLD, 20));
	    button.setStyle(String.format(
	        "-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold;",
	        color, darkenColor(color), TEXT_WHITE, color
	    ));
	    
	    // Enhanced hover effects
	    button.setOnMouseEntered(_ -> button.setStyle(String.format(
	        "-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 4; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.6), 20, 0, 0, 8); -fx-font-weight: bold; -fx-scale-x: 1.05; -fx-scale-y: 1.05;",
	        lightenColor(color), color, TEXT_WHITE, lightenColor(color)
	    )));
	    
	    button.setOnMouseExited(_ -> button.setStyle(String.format(
	        "-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold; -fx-scale-x: 1.0; -fx-scale-y: 1.0;",
	        color, darkenColor(color), TEXT_WHITE, color
	    )));
	    
	    return button;
	}
	
	/**
	 * Helper method to darken colors for gradients
	 */
	private static String darkenColor(String color) {
	    return color + "CC"; // Add transparency for darker effect
	}
	
	/**
	 * Helper method to lighten colors for hover effects
	 */
	private static String lightenColor(String color) {
	    return color + "FF"; // Full opacity for lighter effect
	}
	
	/**
	 * Helper method to create modern menu buttons
	 */
	private static MenuButton createModernMenuButton(String text, String color, int width, int height) {
	    MenuButton menuButton = new MenuButton(text);
	    menuButton.setPrefSize(width, height);
	    menuButton.setFont(Font.font("Arial Black", FontWeight.BOLD, 18));
	    menuButton.setStyle(String.format(
	        "-fx-background-color: linear-gradient(135deg, %s, %s); -fx-text-fill: %s; -fx-background-radius: 15; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 15, 0, 0, 5); -fx-font-weight: bold;",
	        color, darkenColor(color), TEXT_WHITE, color
	    ));
	    return menuButton;
	}

	/**
	 * Modern Administrator Login - High Contrast Design
	 */
	public static void administratorLogin(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("⚙️ ADMINISTRATOR ACCESS");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 36));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("Secure Administrative Login");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Login form card
		VBox loginCard = new VBox(30);
		loginCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		loginCard.setAlignment(Pos.CENTER);
		
		// Username section
		VBox usernameSection = new VBox(10);
		Label usernameLabel = new Label("👤 USERNAME");
		usernameLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		usernameLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
	    TextField username = new TextField();
		username.setPromptText("Enter administrator username");
		username.setPrefSize(350, 50);
		username.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_RED, TEXT_BRIGHT
		));
		
		usernameSection.getChildren().addAll(usernameLabel, username);
		
		// Password section
		VBox passwordSection = new VBox(10);
		Label passwordLabel = new Label("🔐 PASSWORD");
		passwordLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		passwordLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
	    TextField password = new TextField();
		password.setPromptText("Enter administrator password");
		password.setPrefSize(350, 50);
		password.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_RED, TEXT_BRIGHT
		));
		
		passwordSection.getChildren().addAll(passwordLabel, password);
		
		// Button section
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button loginButton = createModernButton("🚀 LOGIN", PRIMARY_GREEN, 150, 60);
		Button backButton = createModernButton("⬅️ BACK", PRIMARY_RED, 150, 60);
		
		buttonSection.getChildren().addAll(backButton, loginButton);
		
		// Assemble login card
		loginCard.getChildren().addAll(usernameSection, passwordSection, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, loginCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		control.navigation.button3Login.setScene(scene, primaryStage);
		
		// Event handlers
		backButton.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		loginButton.setOnAction(_ -> control.auth.administratorLogin.login(primaryStage, username.getText(), password.getText()));
	}

	/**
	 * Modern Manager Login - High Contrast Design
	 */
	public static void managerLogin(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("👔 MANAGER ACCESS");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 36));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("Management Portal Login");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Login form card
		VBox loginCard = new VBox(30);
		loginCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		loginCard.setAlignment(Pos.CENTER);
		
		// Username section
		VBox usernameSection = new VBox(10);
		Label usernameLabel = new Label("👤 USERNAME");
		usernameLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		usernameLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		TextField username = new TextField();
		username.setPromptText("Enter manager username");
		username.setPrefSize(350, 50);
		username.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_GREEN, TEXT_BRIGHT
		));
		
		usernameSection.getChildren().addAll(usernameLabel, username);
		
		// Password section
		VBox passwordSection = new VBox(10);
		Label passwordLabel = new Label("🔐 PASSWORD");
		passwordLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		passwordLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		TextField password = new TextField();
		password.setPromptText("Enter manager password");
		password.setPrefSize(350, 50);
		password.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_GREEN, TEXT_BRIGHT
		));
		
		passwordSection.getChildren().addAll(passwordLabel, password);
		
		// Button section
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button loginButton = createModernButton("🚀 LOGIN", PRIMARY_GREEN, 150, 60);
		Button backButton = createModernButton("⬅️ BACK", PRIMARY_RED, 150, 60);
		
		buttonSection.getChildren().addAll(backButton, loginButton);
		
		// Assemble login card
		loginCard.getChildren().addAll(usernameSection, passwordSection, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, loginCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		primaryStage.setFullScreen(true);
		
		// Event handlers
		backButton.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		loginButton.setOnAction(_ -> control.auth.managerLogin.login(primaryStage, username.getText(), password.getText()));
	}

	
	/**
	 * Modern Cashier Login - High Contrast Design
	 */
	public static void cashierLogin(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("💳 CASHIER ACCESS");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 36));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("Point of Sale Login");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Login form card
		VBox loginCard = new VBox(30);
		loginCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 20; -fx-padding: 40; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 25, 0, 0, 8);",
			CARD_BG
		));
		loginCard.setAlignment(Pos.CENTER);
		
		// Username section
		VBox usernameSection = new VBox(10);
		Label usernameLabel = new Label("👤 USERNAME");
		usernameLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		usernameLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		TextField username = new TextField();
		username.setPromptText("Enter cashier username");
		username.setPrefSize(350, 50);
		username.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_BLUE, TEXT_BRIGHT
		));
		
		usernameSection.getChildren().addAll(usernameLabel, username);
		
		// Password section
		VBox passwordSection = new VBox(10);
		Label passwordLabel = new Label("🔐 PASSWORD");
		passwordLabel.setFont(Font.font("Arial Black", FontWeight.BOLD, 16));
		passwordLabel.setStyle(String.format("-fx-text-fill: %s;", TEXT_WHITE));
		
		TextField password = new TextField();
		password.setPromptText("Enter cashier password");
		password.setPrefSize(350, 50);
		password.setStyle(String.format(
			"-fx-background-color: %s; -fx-text-fill: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 12; -fx-background-radius: 12; -fx-font-size: 16px; -fx-font-weight: bold; -fx-prompt-text-fill: %s; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
			DARK_BG, TEXT_WHITE, PRIMARY_BLUE, TEXT_BRIGHT
		));
		
		passwordSection.getChildren().addAll(passwordLabel, password);
		
		// Button section
		HBox buttonSection = new HBox(30);
		buttonSection.setAlignment(Pos.CENTER);
		
		Button loginButton = createModernButton("🚀 LOGIN", PRIMARY_GREEN, 150, 60);
		Button backButton = createModernButton("⬅️ BACK", PRIMARY_RED, 150, 60);
		
		buttonSection.getChildren().addAll(backButton, loginButton);
		
		// Assemble login card
		loginCard.getChildren().addAll(usernameSection, passwordSection, buttonSection);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, loginCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		primaryStage.setFullScreen(true);
		
		// Event handlers
		backButton.setOnAction(_-> control.navigation.cashierBackButton.back(primaryStage));
		loginButton.setOnAction(_->{
			control.auth.cashierLogin.login(primaryStage, username.getText(), password.getText());
		});
	}

	public static void home(Stage primaryStage) {
		primaryStage.setScene(home);
		primaryStage.setFullScreen(true);
	}
	/**
	 * Modern Cashier Terminal - High Contrast Design
	 */
	public static void cashierLoginTerminal(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("💳 CASHIER TERMINAL");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 40));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("Point of Sale Operations");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Terminal card with modern styling
		VBox terminalCard = new VBox(40);
		terminalCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 25; -fx-padding: 50; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 30, 0, 0, 10);",
			CARD_BG
		));
		terminalCard.setAlignment(Pos.CENTER);
		
		// Cashier operations menu
		MenuButton cashierMenu = createModernMenuButton("💳 CASHIER OPERATIONS", PRIMARY_BLUE, 300, 80);
		MenuItem createBillItem = new MenuItem("📝 Create New Bill");
		MenuItem viewStatsItem = new MenuItem("📊 View Bill Statistics");
		createBillItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		viewStatsItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		cashierMenu.getItems().addAll(createBillItem, viewStatsItem);
		
		// Navigation menu
		MenuButton navMenu = createModernMenuButton("🧭 NAVIGATION", PRIMARY_GREEN, 300, 80);
		MenuItem loginNavItem = new MenuItem("🏠 Main Login");
		MenuItem cashierNavItem = new MenuItem("💳 Cashier Login");
		loginNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		cashierNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		navMenu.getItems().addAll(loginNavItem, cashierNavItem);
		
		terminalCard.getChildren().addAll(cashierMenu, navMenu);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, terminalCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		createBillItem.setOnAction(_ -> control.cashier.menu1.menu1(primaryStage));
		viewStatsItem.setOnAction(_ -> control.cashier.menu2Transition.transition(primaryStage));
		loginNavItem.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		cashierNavItem.setOnAction(_ -> control.navigation.button1Login.cashierLoginTransition(primaryStage));
	}

	/**
	 * Modern Manager Terminal - High Contrast Design
	 */
	public static void managerLoginTerminal(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("👔 MANAGER TERMINAL");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 40));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("Management Operations Center");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Terminal card with modern styling
		VBox terminalCard = new VBox(40);
		terminalCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 25; -fx-padding: 50; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 30, 0, 0, 10);",
			CARD_BG
		));
		terminalCard.setAlignment(Pos.CENTER);
		
		// Manager operations menu
		MenuButton managerMenu = createModernMenuButton("👔 MANAGER OPERATIONS", PRIMARY_GREEN, 350, 80);
		MenuItem addCategoryItem = new MenuItem("📂 Add Product Category");
		MenuItem addProductItem = new MenuItem("📦 Add New Product");
		MenuItem viewStatsItem = new MenuItem("📊 View Bill Statistics");
		MenuItem notificationsItem = new MenuItem("🔔 Notifications");
		
		addCategoryItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		addProductItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		viewStatsItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		notificationsItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		
		managerMenu.getItems().addAll(addCategoryItem, addProductItem, viewStatsItem, notificationsItem);
		
		// Navigation menu
		MenuButton navMenu = createModernMenuButton("🧭 NAVIGATION", PRIMARY_BLUE, 300, 80);
		MenuItem loginNavItem = new MenuItem("🏠 Main Login");
		MenuItem managerNavItem = new MenuItem("👔 Manager Login");
		loginNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		managerNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		navMenu.getItems().addAll(loginNavItem, managerNavItem);
		
		terminalCard.getChildren().addAll(managerMenu, navMenu);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, terminalCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		addCategoryItem.setOnAction(_ -> control.manager.menagerMenu1.menagerMenu1(primaryStage));
		addProductItem.setOnAction(_ -> control.manager.managerMenu3.managerMenu3(primaryStage));
		viewStatsItem.setOnAction(_ -> control.manager.managerMenu2.managerMenu2(primaryStage));
		notificationsItem.setOnAction(_ -> control.manager.managerMenu4.managerMenu4(primaryStage));
		loginNavItem.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		managerNavItem.setOnAction(_ -> control.navigation.button2Login.managerLoginTransition(primaryStage));
	}

	/**
	 * Modern Administrator Terminal - High Contrast Design
	 */
	public static void administratorLoginTerminal(Stage primaryStage) {
		// Create main container with modern dark gradient
		VBox mainContainer = new VBox(40);
		mainContainer.setStyle(String.format(
			"-fx-background-color: linear-gradient(135deg, %s 0%%, %s 100%%); -fx-padding: 60;",
			DARK_BG, CARD_BG
		));
		
		// Header section
		VBox headerSection = new VBox(20);
		headerSection.setAlignment(Pos.CENTER);
		
		Text title = new Text("⚙️ ADMINISTRATOR TERMINAL");
		title.setFont(Font.font("Arial Black", FontWeight.BOLD, 40));
		title.setFill(javafx.scene.paint.Color.web(TEXT_WHITE));
		title.setEffect(new Glow(0.8));
		
		Text subtitle = new Text("System Administration Center");
		subtitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
		subtitle.setFill(javafx.scene.paint.Color.web(TEXT_BRIGHT));
		
		headerSection.getChildren().addAll(title, subtitle);
		
		// Terminal card with modern styling and glow effect
		VBox terminalCard = new VBox(40);
		terminalCard.setStyle(String.format(
			"-fx-background-color: %s; -fx-background-radius: 25; -fx-padding: 50; -fx-effect: dropshadow(three-pass-box, rgba(255,255,255,0.2), 30, 0, 0, 10);",
			CARD_BG
		));
		terminalCard.setAlignment(Pos.CENTER);
		
		// Add animated glow effect
		Glow glow = new Glow(0.6);
		Animation glowAnimation = new Timeline(
			new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0.6)),
			new KeyFrame(Duration.seconds(2), new KeyValue(glow.levelProperty(), 1.0)),
			new KeyFrame(Duration.seconds(4), new KeyValue(glow.levelProperty(), 0.6))
		);
		glowAnimation.setCycleCount(Animation.INDEFINITE);
		glowAnimation.setAutoReverse(true);
		terminalCard.setEffect(glow);
		glowAnimation.play();
		
		// Administrator operations menu
		MenuButton adminMenu = createModernMenuButton("⚙️ ADMIN OPERATIONS", PRIMARY_RED, 350, 80);
		MenuItem addEmployeeItem = new MenuItem("➕ Add Employee");
		MenuItem editEmployeeItem = new MenuItem("✏️ Edit Employee");
		MenuItem deleteEmployeeItem = new MenuItem("🗑️ Delete Employee");
		MenuItem viewStatsItem = new MenuItem("📊 View Statistics");
		
		addEmployeeItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		editEmployeeItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		deleteEmployeeItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		viewStatsItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		
		adminMenu.getItems().addAll(addEmployeeItem, editEmployeeItem, deleteEmployeeItem, viewStatsItem);
		
		// Navigation menu
		MenuButton navMenu = createModernMenuButton("🧭 NAVIGATION", ACCENT_PURPLE, 300, 80);
		MenuItem loginNavItem = new MenuItem("🏠 Main Login");
		MenuItem adminNavItem = new MenuItem("⚙️ Administrator Login");
		loginNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		adminNavItem.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		navMenu.getItems().addAll(loginNavItem, adminNavItem);
		
		terminalCard.getChildren().addAll(adminMenu, navMenu);
		
		// Assemble main layout
		mainContainer.getChildren().addAll(headerSection, terminalCard);
		mainContainer.setAlignment(Pos.CENTER);
		
		Scene scene = new Scene(mainContainer, 1200, 900);
		primaryStage.setScene(scene);
		
		// Event handlers
		addEmployeeItem.setOnAction(_ -> control.admin.Administrator.menu1(primaryStage));
		editEmployeeItem.setOnAction(_ -> control.admin.Administrator.menu2(primaryStage));
		deleteEmployeeItem.setOnAction(_ -> control.admin.Administrator.menu3(primaryStage));
		viewStatsItem.setOnAction(_ -> control.admin.Administrator.menu4(primaryStage));
		loginNavItem.setOnAction(_ -> control.navigation.cashierBackButton.back(primaryStage));
		adminNavItem.setOnAction(_ -> control.navigation.button3Login.administratorLoginTransition(primaryStage));
	}

	/**
	 * Modern Login Alert - High Contrast Design
	 */
	public static void loginAlert() {
	    Alert alert = new Alert(Alert.AlertType.ERROR);
	    alert.setTitle("🚫 Authentication Failed");
	    alert.setHeaderText("Invalid Credentials");
	    alert.setContentText("The username or password you entered is incorrect.\n\nPlease verify your credentials and try again.");
	    
	    DialogPane dialogPane = alert.getDialogPane();
	    dialogPane.setStyle(String.format(
	        "-fx-background-color: %s; -fx-border-color: %s; -fx-border-width: 3; -fx-border-radius: 15; -fx-background-radius: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.4), 20, 0, 0, 8);",
	        CARD_BG, PRIMARY_RED
	    ));
	    
	    // Style header
	    if (dialogPane.lookup(".header-panel") != null) {
	        dialogPane.lookup(".header-panel").setStyle(String.format(
	            "-fx-background-color: %s; -fx-text-fill: %s; -fx-font-size: 18px; -fx-font-weight: bold; -fx-padding: 15;",
	            PRIMARY_RED, TEXT_WHITE
	        ));
	    }
	    
	    // Style content
	    if (dialogPane.lookup(".content") != null) {
	        dialogPane.lookup(".content").setStyle(String.format(
	            "-fx-text-fill: %s; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 15;",
	            TEXT_WHITE
	        ));
	    }
	    
	    // Style OK button
	    if (alert.getDialogPane().lookupButton(ButtonType.OK) != null) {
	        alert.getDialogPane().lookupButton(ButtonType.OK).setStyle(String.format(
	            "-fx-background-color: %s; -fx-text-fill: %s; -fx-background-radius: 10; -fx-border-color: %s; -fx-border-width: 2; -fx-font-weight: bold; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 8, 0, 0, 2);",
	            PRIMARY_RED, TEXT_WHITE, darkenColor(PRIMARY_RED)
	        ));
	    }
	    
	    alert.showAndWait();
	}

}
