package view;

public class administratorMenu1 {

}
