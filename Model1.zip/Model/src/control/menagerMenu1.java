package control;
import javafx.stage.Stage;
public class menagerMenu1 {
public static void menagerMenu1(Stage primaryStage) {
	view.Manager.menu1(primaryStage);
}
}
