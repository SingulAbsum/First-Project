package control;
import javafx.stage.*;
public class menu2Transition {
public static void transition(Stage primaryStage) {
	view.Cashier.menu2(primaryStage);
}
}
