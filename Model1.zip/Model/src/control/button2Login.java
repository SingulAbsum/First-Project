package control;
import javafx.stage.Stage;
public class button2Login {
public static void managerLoginTransition(Stage primaryStage) {
	view.mainLogin.managerLogin(primaryStage);
}
}
