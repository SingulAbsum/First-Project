package control;
import javafx.stage.Stage;
public class managerMenu2 {
public static void managerMenu2(Stage primaryStage) {
	view.Manager.menu2(primaryStage);
}
}
