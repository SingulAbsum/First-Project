package control;
import javafx.stage.Stage;
public class aministratorBackButton {
public static void back(Stage primaryStage) {
	
}
}
