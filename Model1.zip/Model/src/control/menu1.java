package control;
import javafx.stage.*;
public class menu1 {
public static void menu1(Stage primaryStage) {
view.Cashier.menu1(primaryStage);
}
}
